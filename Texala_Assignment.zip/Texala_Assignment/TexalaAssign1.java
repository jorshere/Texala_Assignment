package com.qsp.Project;

import java.util.Scanner;

public class TexalaAssign1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the URL");
		String URL = scanner.nextLine();

		Service ser = new Service();
		String output = ser.readHTML(URL);
		System.out.println(output);
	}
	
	
}
