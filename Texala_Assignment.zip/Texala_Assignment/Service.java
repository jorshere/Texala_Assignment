package com.qsp.Project;

import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Service {
	
	
	public String readHTML(String url) {
		String content = null;
		URLConnection con = null;
		try {
		  con =  new URL(url).openConnection();
		  Scanner scanner = new Scanner(connection.getInputStream());
		  scanner.useDelimiter("\\Z");
		  content = scanner.next();
		  scanner.close();
		  File file1 = new File("web-context.txt");
		  file1.createNewFile();
		  FileWriter fileWriter=new FileWriter(file1);
		  fileWriter.write(content);
		  fileWriter.flush();
		  fileWriter.close();
		}catch ( Exception ex ) {
			System.out.println("check url")
		   
		}
		return content;
	}
}
